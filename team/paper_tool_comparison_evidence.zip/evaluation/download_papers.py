"""Download original test inputs and verify against the recorded baseline."""
from pathlib import Path
import urllib.request
import hashlib
import json
ROOT=Path(__file__).resolve().parent
URLS={
 'ipmix':'https://proceedings.neurips.cc/paper_files/paper/2023/file/c917d8b9e01427f3184d80ade22f4d1f-Paper-Conference.pdf',
 'backdoor':'https://proceedings.neurips.cc/paper_files/paper/2022/file/76917808731dae9e6d62c2a7a6afb542-Paper-Conference.pdf',
 'fingerprinting':'https://openaccess.thecvf.com/content/CVPR2022/papers/Peng_Fingerprinting_Deep_Neural_Networks_Globally_via_Universal_Adversarial_Perturbations_CVPR_2022_paper.pdf',
}
if __name__=='__main__':
 (ROOT/'papers').mkdir(exist_ok=True)
 expected=json.loads((ROOT/'baseline_results.json').read_text())
 for name,url in URLS.items():
  data=urllib.request.urlopen(url,timeout=60).read()
  if not data.startswith(b'%PDF'): raise ValueError(f'{name}: not a PDF')
  if hashlib.sha256(data).hexdigest()!=expected[name]['sha256']: raise ValueError(f'{name}: input changed')
  (ROOT/'papers'/f'{name}.pdf').write_bytes(data)
  print(name,'verified')
