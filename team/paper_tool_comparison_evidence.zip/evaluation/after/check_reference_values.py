"""Check selected, previously reviewed cells; not a whole-paper accuracy score."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
before=json.loads((ROOT.parent/'before'/'baseline_results.json').read_text())
after=json.loads((ROOT/'results.json').read_text())
for paper in before:
 assert before[paper]['sha256']==after[paper]['sha256'], 'PDF changed'
checks=[]
expected=[22.2,63,57.4,48.5,7.1,7,30,6.6,18.2]
obs=after['ipmix']['details']['observations']
row=[o for o in obs if o.get('method')=='IPMix' and o['source'].get('table')=='5']
for col,value in enumerate(expected,1):
 found=[o for o in row if o['source']['column']==col and o['value']==value]
 checks.append({'paper':'ipmix','table':5,'row':'IPMix','column':col,'expected':value,'passed':len(found)==1})
obs=after['backdoor']['details']['observations']
for method,vals in [('EP (Ours)',[93.88,.86]),('BNP (Ours)',[93.6,1.6])]:
 for col,value in enumerate(vals,1):
  found=[o for o in obs if o.get('method')==method and o['source'].get('table')=='1' and o['source']['column']==col and o['value']==value]
  checks.append({'paper':'backdoor','table':1,'row':method,'column':col,'expected':value,'passed':len(found)==1})
(ROOT/'reference_checks.json').write_text(json.dumps(checks,indent=2))
assert all(c['passed'] for c in checks)
print(f'{len(checks)} checked cells matched; no claim about unchecked cells.')
