import sys,pathlib,json,hashlib,time
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'fair_fairness_benchmark'))
from team.eval_metrics_tool.eval_metrics import extract_eval_metrics_report
from team.initialize_metrics_record_tool import initialize_metrics_record,extract_metric_observations
results={}
for p in sorted((ROOT.parent/'papers').glob('*.pdf')):
 start=time.perf_counter()
 found=extract_eval_metrics_report(str(p),use_llm=False)
 record=initialize_metrics_record(str(p),found['metrics'])
 observations=extract_metric_observations(str(p))
 results[p.stem]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'extraction':found,'record':record,'details':observations,'elapsed_seconds':time.perf_counter()-start}
 print(p.stem,found['metrics'],record,len(observations['observations']),found['experiments_characters'],flush=True)
 (ROOT/'results.json').write_text(json.dumps(results,indent=2))
