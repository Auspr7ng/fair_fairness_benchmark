# Paper-reading tools: results after improvements

**October 19, 2026**

The code now reads more useful information and avoids several misleading answers. **All 114 tests pass, including 22 new tests.** The original report has been preserved for comparison.

The biggest improvement is that the tools can return separate results with the supporting table row or passage. They no longer have to squeeze a whole paper’s experiments into one number.

## What changed

- **Meaning is preserved.** “Less than 1%” and “greater than 80%” are kept as bounds in the detailed results. They are not saved as exact values in the older, simpler output.
- **Error and accuracy are separate.** The code no longer labels a top-1 error result as top-1 accuracy.
- **More measure names are supported.** These include corruption error, prediction changes, confidence calibration, model similarity, and common abbreviations.
- **PDF reading is better.** The reader handles spacing more carefully and separates two columns when it finds a clear gap.
- **Results carry evidence.** The new output keeps table rows, column positions, headings, and available page numbers. Unclear dataset or model names are left blank for review.
- **The agent has paper-reading tools.** It can now call the reader and result collector. Importing its code no longer starts an AI model.
- **Input checks and documentation were improved.** Both update functions reject invalid numbers, and the README now describes the tests and limitations correctly.

## Before and after

The same three PDFs were used, and their file checksums were verified to match the first run.

| Paper | Before | After |
|---|---|---|
| **IPMix** | Found two measure names and filled in no values. | Finds the previously missed measures. The detailed reader correctly recovers all nine values in the checked IPMix row of Table 5. |
| **Backdoor-neuron paper** | Saved “less than 1%” as exactly `1.0`. | Keeps the “less than” meaning. The four checked accuracy/attack-success values for EP and BNP are recovered from Table 1. |
| **Fingerprinting paper** | Could not find the Experiments section; saved “greater than 80%” as exactly `80.0`. | Finds the Experiments section and preserves “greater than.” It also recognizes model-similarity measures, but does not fully separate the paper’s multi-dataset results. |

**All 13 selected table cells matched the values checked in the original papers.** This is a check of those cells, not an accuracy score for every result in the papers. The detailed reader returns other candidates that have not all been manually verified.

The older one-number-per-measure output now leaves all selected values blank in these three unqualified runs. That is deliberate: it avoids choosing one experiment without enough context. Use the detailed output to review the separate results.

## What the new tests check

The added tests cover comparison signs, unfamiliar requested measure names, error versus accuracy, repeated table columns, missing table cells, two-column reading order, source details, invalid updates, and agent tool availability.

The rerun also exposed nearby figure numbers and ranges being mistaken for results. The code now requires a direct value statement or table alignment for the simpler output, and avoids choosing a single value from a comma-separated list of results.

## What still needs work

**Human review is still needed.** The detailed output keeps grouped table headings but does not reliably turn every heading into a separate dataset, model, or attack label. Every candidate is therefore marked as needing review.

**Some layouts remain difficult.** Complex tables, figures, scanned pages, and values reported across several sentences are not fully handled. The fingerprinting paper is the clearest remaining example.

**Live AI quality is still untested.** The agent’s tools were tested directly, but Qwen or another live model has not been run. Connecting the tools does not prove that a model will choose and use them correctly.

**Broader testing is needed.** These changes were developed using the same three papers. Testing new papers is the next step before claiming that the improvements work generally. Automatic correction history and protection against simultaneous record edits also remain future work.

## Using the changes

To get separate results with evidence, run this from the repository root:

```bash
python -m team.initialize_metrics_record_tool paper.pdf --observations
```

The original functions remain available. A new `extract_eval_metrics_report` function also shows whether results came from the dictionary or an AI model, and explains any switch to the dictionary.

The changes are committed locally on branch `improve-paper-extraction`, commit `46a170b81b1292cf7573804b7b960f233575549b`. The supplied patch applies to the originally tested repository version:

```bash
git am /path/to/paper_extraction_improvements.patch
```

The GitHub repository has not been changed. GitHub was installed, but authenticated repository tools were not exposed in this session, and a direct push failed because no GitHub credentials were available. The accompanying test evidence contains the before-and-after outputs, selected-cell checks, and test log.
