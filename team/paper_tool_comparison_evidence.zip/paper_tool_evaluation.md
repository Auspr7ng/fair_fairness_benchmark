# How well do the tools read research papers?

**Tested October 19, 2026** · [Repository](https://github.com/Auspr7ng/fair_fairness_benchmark/tree/master/team)

The tools can identify some useful information, but their results still need human review. **All 92 existing tests passed**, yet testing the three papers revealed important mistakes that those tests do not cover.

This review tested the rule-based tools and inspected the agent’s code. **A live AI model was not tested**, so these findings do not measure how well Qwen or another model understands the papers.

## Results for each paper

| Paper | What the tools did | Main problem |
|---|---|---|
| **IPMix** | Found two measure names but filled in no values. | Missed several important measures and could not reliably read the results table. |
| **Pre-activation Distributions Expose Backdoor Neurons** | Found accuracy and attack success rate; stored attack success rate as `1.0`. | The source says **less than 1%**, not exactly 1%. |
| **Fingerprinting Deep Neural Networks** | Found three measure names; stored attack success rate as `80.0`. | The source says **greater than 80%**. The tool also failed to locate the Experiments section. |

For IPMix, missed measures include performance on corrupted images, how well confidence matches correctness, and how often predictions change when images are altered. These appear in the paper as mCE, RMS calibration error, and mean flip rate.

The fingerprinting paper also reports how similar models are and how well the method identifies stolen models. The tools missed important parts of those results.

Across all three papers, the tools selected seven measure names, left five values blank, and filled in two numbers. **Both numbers lost important “less than” or “greater than” information.** A blank value is not always a mistake: leaving it blank can be sensible when several experiments report different numbers.

## Assessment of each tool

### 1. Finding measure names — `eval_metrics_tool`

**What works:** It recognizes familiar names such as accuracy and attack success rate. Its rule-based results can be inspected and explained.

**What needs improvement:** It relies on a fixed list of names, so unfamiliar measures are missed. PDF formatting can mix columns, remove spaces, and confuse section headings. A separate test also showed that it labels “top-1 error” as “Top-1 Accuracy,” even though error and accuracy mean different things.

**Recommended change:** Expand the supported names, keep error separate from accuracy, and improve how the tool reads columns and tables. Show the page or passage supporting each result.

### 2. Finding values — `initialize_metrics_record_tool`

**What works:** It can extract a clearly stated value and can leave a result blank when the answer is unclear.

**What needs improvement:** It drops comparison signs and stores only one number for each measure. That is too limiting when a paper reports different results for different datasets, models, or attacks. Even supplying a missing measure’s name does not necessarily let it find the value.

**Recommended change:** Save each result with its dataset, method, experimental conditions, and source location. Preserve “less than,” “greater than,” and uncertainty information.

For example, the backdoor paper reports attack success rates of **0.86% for EP** and **1.60% for BNP** under the same selected dataset and attack. One paper-wide number cannot represent both.

### 3. Updating records — `insert_into_record_tool`

**What works:** The main updater passed tests for changing values, saving and loading files, and rejecting invalid entries. It manages records; it does not read papers.

**What needs improvement:** The simpler update function in the initializer accepts invalid entries that the main updater rejects.

**Recommended change:** Make both functions enforce the same checks. Keep a history of corrections and their sources.

### 4. Coordinating the tools — `basic_agent.py`

**Current limitation:** The agent can list experiment scripts and update records, but the paper-reading tools are not connected to it. It cannot yet perform the complete paper-reading task through its registered tools.

**Recommended change:** Connect the reader and initializer, then test whether the agent chooses the right tools and uses supported values. Live model testing is still needed.

## What to improve first

1. **Stop changing the meaning of results.** Preserve comparison signs and distinguish error from accuracy.
2. **Keep experimental context.** Store separate results for different datasets, models, and methods.
3. **Improve PDF reading.** Focus on columns, table headings, and matching numbers to the correct rows.
4. **Support more measures.** Include names and abbreviations used in these papers.
5. **Add tests for these failures.** Also fix the README’s conflicting installation text and outdated statement that no tests exist.

## A better way to test

Manually check a small set of expected results in each paper, recording the page and table for every answer. Then judge each step separately:

- Did the tool find the right measure?
- Did it find the right value and preserve its meaning?
- Did it attach that value to the correct experiment?
- Did it leave the answer blank when there was not enough information?

Compare the rule-based method and the AI-assisted method on the same examples. After making improvements, test additional papers that were not used to guide the changes. Include fairness papers as well as these security and robustness papers.

**Next decisions:** Choose which AI model to test and whether the desired output should include all experiments or only the authors’ proposed methods. I recommend keeping separate results for each experiment, with comparison methods clearly labeled.

---

**Test record:** Repository version `179e6454dedc809582f401310f587724346cfe9a`. Only the three main conference PDFs were tested; separate supplements were excluded. Selected results were checked against the original tables. The accompanying evidence ZIP contains the scripts and detailed outputs. These three papers reveal useful problems, but are too small a sample for a general accuracy score.
